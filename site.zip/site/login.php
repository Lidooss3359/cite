<?php
    session_start();
?>
    <html>
        <head>
            <title>Авторизация</title>
        </head>
    <body>
    <div align="center">
    <h2>Авторизация</h2>
 <form action="functions/testreg.php" method="post">
    <p>
        <label>Ваш логин:<br></label>
        <input name="login" type="text" size="15" maxlength="15">
    </p>
    <p>
        <label>Ваш пароль:<br></label>
        <input name="password" type="password" size="15" maxlength="15">
    </p>
    <p>
        <input type="submit" name="submit" value="Войти"><br>
        <a href="register.php">Зарегистрироваться</a> 
    </p>
 </form><br>
    
    <?php
    // Проверяем, пусты ли переменные логина и id пользователя
    if (empty($_SESSION['login']) or empty($_SESSION['id']))
    {
    // Если пусты, то мы не выводим ссылку
    echo "Вы вошли на сайт, как гость<br><a href='#'>Эта ссылка  доступна только зарегистрированным пользователям</a>";
    }
    else
    {

    // Если не пусты, то мы выводим ссылку
    echo "Вы вошли на сайт, как ".$_SESSION['login']."<br><a  href='index.php'>Эта ссылка доступна только  зарегистрированным пользователям</a>";
    $_SESSION['login'] = $_POST['login'];
//    setcookie("cookieuser", $_SESSION['login'], strtotime("+1 days"));
    }
    ?>
    </div>
    </body>
    </html>