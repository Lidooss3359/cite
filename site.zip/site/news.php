<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "site");
if (!$conn) {
  die("Ошибка: " . mysqli_connect_error());
}

$id = isset($_GET['id']) && !empty($_GET['id']) ? $_GET['id'] : null;

if (is_null($id)) {
	exit('Error');
}

$sql = "SELECT * FROM post WHERE id = $id";

if($result = $conn->query($sql)){
    foreach($result as $row){   
	$article = 	[
		'id'=> $row["id"],
		'title'=> $row["Title"],
		'Foto' => $row["Foto"],
		'Intro' => $row["Intro"],
		'body'=> $row["Text"],
		'autor' => $row["autor"],
		'Published_date' => $row["Published_date"]
	];
}
}

include_once("header.php");
$page_id = $article['id']; // Уникальный идентификатор страницы (статьи или поста)

function article_edit($id, $Title, $Foto, $Intro, $Text, $autor, $Published_date){
	
}
function article_delete($id){
	
}


?>

<!DOCTYPE html>
<html>
<head>
	<title><?= $row['Title']?></title>

</head>
<body>
<div class="container">
        <div class="row">
            <div class="col-sm">
        		<img src="https://www.intrare.info/images/blog/single-post.jpg" class="img-fluid" alt="https://www.intrare.info/images/blog/single-post.jpg">
	   	</div>
        </div>
        <div class="row">
	        <?php
	            include_once("bok.php");
	        ?>
			<div class=col>
				<h1><?= $row['Title']?></h1>
				<img src= "<?= $row['Foto']?>" alt="foto" align="left" hspace=10 width=250 height=250>
				<p><?= $row['Text']?></p><br></br>
				<p>Автор: <?= $row['autor']?> <br>Дата написания: <?= $row['Published_date']?></p>
				<button class="button"><a class="button" href="index.php">Ввернуться на главную</a></button></br></br>
			</div>
		</div
		
		<div class="row">
<div class=col-3> </div>
<div class="col">
<?php if ($_SESSION['login']==$row['autor']){?>
<div align="left">
<h2> Редактирование статьи </h2>
<form action="functions/redpost.php?id=<?= $row['id'] ?>" method="post" enctype="multipart/form-data">
<input type="hidden" name="autor" value="<?= $_SESSION['login']?>"><br>
<input type="text" name="title1" placeholder="Введите название статьи" size="30" value="<?=$row["Title"]?>"><br>
<textarea type="text" name="text1" placeholder="Введите текст статьи" cols="100%" rows="5" value=<?= $row["Foto"]?>> <?= $row["Text"]?></textarea>
<button type="submit" class="btn btn-primary btn-lg">Изменить</button>
</form>
</div>
<?php } ?>
</div>
</div>
		
<?php
$sql = "SELECT * FROM user";

if($result = $conn->query($sql)){
foreach($result as $row){
$article = [
'name'=> $_SESSION["login"],
];
}
}
?>		
		
		
		
	
            <?php
			$result_set = $conn->query("SELECT * FROM `comment` WHERE `page_id`= '$page_id' "); 
			//Вывод комментариев
			while ($row = $result_set->fetch_assoc()) { ?>
				<div class='brd'>
				<h1><?= $row['autor']?></h1>
				<div class='brd2'><p><?= $row['text']?></p></div>
				</div>
			    <br> </br>
			<?php } ?> 
	<div class="row">
		
<?php
$sql = "SELECT * FROM user";

if($result = $conn->query($sql)){
    foreach($result as $row){   
	$article = 	[
		'login'=> $_SESSION["login"],
	];
}
}
?>
		<div class=col-6>
		<h2>Чтобы оставить комментарий, заполните форму</h2><br>
			<div class="col">
				<form name="comment" action="functions/comment.php" method="post">
				  <p>
				    <label>Имя:</label>
				    <div name="autor"></div>
				    <input type="text" name="autor" placeholder="<?= $_SESSION['login']?>"></input>				    
				  </p>
				  <p>
				    <label>Комментарий:</label>
				    <br />
				    <textarea name="text" cols="50" rows="5"></textarea>
				  </p>
				  <p>
				    <input type="hidden" name="page_id" value="<?= $page_id ?>" /> 
				    <input type="submit" value="Отправить" />
				  </p>
				</form>			
			
			</div>
			
		</div>
	</div>
</div>
</body>
</html>