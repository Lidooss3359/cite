<?php 
session_start();

$conn = mysqli_connect("localhost", "root", "", "site");
if (!$conn) {
  die("Ошибка: " . mysqli_connect_error());
}

$sql = "SELECT * FROM post";
include_once("header.php");
?>

<html>
  <head>
  	<meta charset="utf-8">
  	<title>Личный кабинет</title>
  	<link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="col-sm">
        		<img src="https://www.intrare.info/images/blog/single-post.jpg" class="img-fluid" alt="https://www.intrare.info/images/blog/single-post.jpg">
	   	</div>
      </div>
    <div class="row">
       <div class="col-3"> 
       				<?php
					echo "Чтобы выйти со своего аккаунта нажмите "; 
					if(isset($_GET['exit']))
					{
					    session_destroy();
					    header('Location: index.php');
					    exit;
					}
				?>
			<a href="?exit">выйти</a>
		</div>
		
		<div class="col-6">    
				<form action="functions/predlog.php" method="post" name="form">
					<b>Для того, чтобы предложить пост, заполните форму</b></br><br>
					<input type="hidden" name="autor" value="<?= $_SESSION['login']?>" /><br>
					<input type="text" name="Title" placeholder="Введите название статьи" size="30"></br><br>
					<input type="text" name="Intro" placeholder="Краткое содержание" size="30"><br><br>
					<textarea type="text" name="Text" placeholder="Введите текст статьи"cols="50" rows="5"></textarea><br>
					<br><p><input type="file" name="foto"></br>
					<p>Введите дату выкладывания поста<input type="date" id="start" name="Date"></p>
					<input type="submit" placeholder="Отправить">
				</form>
	    </div>
	</div>
		
		
			   
			
		</div>
  </body>
</html>
