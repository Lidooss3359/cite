<?php
session_start();

// ПОДКЛЮЧЕНИЕ К БД
$conn = mysqli_connect("localhost", "root", "", "site");
if (!$conn) {
  die("Ошибка: " . mysqli_connect_error());
}

$id = $_GET['id'];
$title = $_POST['title1'];
$autor = $_POST['autor'];
$text = $_POST['text1'];



//$sql = "SELECT * FROM post WHERE id = $id";

$result = mysqli_query ($conn,"UPDATE post SET Title = ('$title'), Text = ('$text'), autor = ('$autor') WHERE id = " . $id . " ");

if ($result == true){
echo "Информация занесена в базу данных";
}else{
echo "Информация не занесена в базу данных";
}
?>
